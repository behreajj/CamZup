package camzup.core;

/**
 * Maintains consistent behavior between data contained by entities.
 */
public interface IEntityData extends IUtils {
}