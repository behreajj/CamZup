package camzup.core;

/**
 * An abstract parent for mesh objects.
 */
public abstract class Mesh extends EntityData implements IMesh {

   /**
    * Inserts a 2D array in the midst of another. For use by
    * subdivision functions.
    *
    * @param arr
    *           the array
    * @param index
    *           the insertion index
    * @param insert
    *           the inserted array
    * @return the new array
    * @see System#arraycopy(Object, int, Object, int, int)
    */
   protected static int[][] insert (
         final int[][] arr,
         final int index,
         final int[][] insert ) {

      final int alen = arr.length;
      final int blen = insert.length;
      final int valIdx = Utils.mod(index, alen + 1);

      final int[][] result = new int[alen + blen][];
      System.arraycopy(arr, 0, result, 0, valIdx);
      System.arraycopy(insert, 0, result, valIdx, blen);
      System.arraycopy(arr, valIdx, result, valIdx + blen, alen - valIdx);

      return result;
   }

   /**
    * The material associated with this mesh in a mesh entity.
    */
   public int materialIndex = 0;

   /**
    * The default constructor.
    */
   protected Mesh () {

      super();
   }

   /**
    * Construct a mesh and give it a name.
    *
    * @param name
    *           the name
    */
   protected Mesh ( final String name ) {

      super(name);
   }

   /**
    * Gets this mesh's material index.
    *
    * @return the material index
    */
   public int getMaterialIndex () {

      return this.materialIndex;
   }

   /**
    * Sets this mesh's material index.
    *
    * @param i
    *           the index
    * @return this mesh
    */
   @Chainable
   public Mesh setMaterialIndex ( final int i ) {

      this.materialIndex = i;
      return this;
   }
}