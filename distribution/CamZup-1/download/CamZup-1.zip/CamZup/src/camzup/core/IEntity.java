package camzup.core;

/**
 * Maintains consistent behavior between entities.
 */
public interface IEntity extends IUtils {
}