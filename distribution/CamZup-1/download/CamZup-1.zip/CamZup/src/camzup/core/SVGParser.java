package camzup.core;

import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public abstract class SVGParser {

   protected static final DocumentBuilderFactory dbf = DocumentBuilderFactory
         .newDefaultInstance();

   public static CurveEntity2 parse ( String fileName ) {

      try {
         // dbf.setAttribute("http://apache.org/xml/features/nonvalidating/load-external-dtd",
         // false);
         DocumentBuilder db = dbf.newDocumentBuilder();
         File file = new File(fileName);
         Document doc = db.parse(file);
         Element root = doc.getDocumentElement();
         root.normalize();
         NodeList nodes = root.getChildNodes();
         int nodeLen = nodes.getLength();
         for(int i = 0; i < nodeLen; ++i) {
            Node curr = nodes.item(i);
            NamedNodeMap attributes = curr.getAttributes();
            int attribLen = attributes.getLength();
            for(int j = 0; j < attribLen; ++j) {
               Node attrib = attributes.item(j);
               System.out.println(attrib.getNodeValue());
            }
         }
      } catch (Exception e) {
         e.printStackTrace();
      }
      return new CurveEntity2();
   }
}
