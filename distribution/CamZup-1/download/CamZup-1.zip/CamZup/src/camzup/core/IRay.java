package camzup.core;

import java.io.Serializable;

public interface IRay extends IUtils, Cloneable, Serializable {

}
