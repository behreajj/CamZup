package camzup.core;

/**
 * Maintains consistent behavior for transforms.
 */
public interface ITransform extends IUtils, Cloneable {}
