package camzup.core;

public class Ray implements IRay {

   /**
    * The unique identification for serialized classes.
    */
   private static final long serialVersionUID = 4607443374584899161L;

   /**
    * The default constructor.
    */
   public Ray () {

   }
}
