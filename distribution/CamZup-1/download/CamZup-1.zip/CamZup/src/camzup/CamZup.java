package camzup;

import camzup.core.IUtils;
import camzup.core.Mesh3;
import camzup.core.Random;
import camzup.core.SinCos;
import camzup.core.Utils;
import camzup.core.Vec2;
import camzup.core.Vec3;
import processing.core.PApplet;

/**
 * The main class of this library. This is not needed to use
 * the library and is for development and debugging only.
 */
public class CamZup {

   /**
    * The library's current version.
    */
   public final static String VERSION = "0.0.3";

   static String toHardCode ( final Mesh3 mesh ) {

      final StringBuilder sb = new StringBuilder();
      final int[][][] fs = mesh.faces;
      final Vec3[] vs = mesh.coords;
      final Vec2[] vts = mesh.texCoords;
      final Vec3[] vns = mesh.normals;

      final int flen0 = fs.length;
      for (int i = 0; i < flen0; ++i) {
         final int[][] f = fs[i];
         final int flen1 = f.length;
         sb.append("this.beginShape(PConstants.POLYGON);\n");
         for (int j = 0; j < flen1; ++j) {
            final int[] data = f[j];

            final int vIndex = data[0];
            final Vec3 v = vs[vIndex];

            final int vtIndex = data[1];
            final Vec2 vt = vts[vtIndex];

            final int vnIndex = data[2];
            final Vec3 vn = vns[vnIndex];

            sb.append("this.normal(");
            sb.append(Utils.toFixed(vn.x, 5));
            sb.append("f, ");
            sb.append(Utils.toFixed(vn.y, 5));
            sb.append("f, ");
            sb.append(Utils.toFixed(vn.z, 5));
            sb.append("f);\n");

            sb.append("this.vertexImpl(\n");

            sb.append(Utils.toFixed(v.x, 5));
            if (v.x == 0.0f) {
               sb.append("f, ");
            } else {
               sb.append("f * radius, ");
            }

            sb.append(Utils.toFixed(v.y, 5));
            if (v.y == 0.0f) {
               sb.append("f, ");
            } else {
               sb.append("f * radius, ");
            }

            sb.append(Utils.toFixed(v.z, 5));
            if (v.z == 0.0f) {
               sb.append("f,\n");
            } else {
               sb.append("f * radius,\n");
            }

            sb.append(Utils.toFixed(vt.x, 5));
            sb.append("f, ");

            sb.append(Utils.toFixed(vt.y, 5));
            sb.append("f);\n");
         }
         sb.append("this.endShape(PConstants.CLOSE);\n\n");
      }
      return sb.toString();
   }

   public static void main ( final String[] args ) {

      System.out.println((0.25d / Math.PI));
      int count = 10;
      long start = 0;
      long stop = 0;
      long diff0 = 0;
      long diff1 = 0;
      Random rng = new Random();
      Vec2 target = new Vec2();

      start = System.currentTimeMillis();
      for (int i = 0; i < count; ++i) {
         final double theta = rng.nextDouble() * IUtils.TAU_D;
         final double cost = Math.cos(theta);
         final double sint = Math.sin(theta);
         target.set((float) cost, (float) sint);

         // System.out.println(Utils.tan((float)theta));
         // System.out.println(Math.tan(theta));
      }
      stop = System.currentTimeMillis();
      diff0 = stop - start;
      // System.out.println(diff0);

      start = System.currentTimeMillis();
      for (int i = 0; i < count; ++i) {
         final float theta = rng.nextFloat() * IUtils.TAU;
         Vec2.fromPolar(theta, target);
      }
      stop = System.currentTimeMillis();
      diff1 = stop - start;
      // System.out.println(diff1);

      // System.out.println(Utils.div((double)(diff0 - diff1),
      // (double)diff0));

   }

   /**
    * Gets the version of the library.
    *
    * @return the version
    */
   public static String version () {

      return CamZup.VERSION;
   }

   /**
    * The PApplet referenced by this class.
    */
   public final PApplet parent;

   /**
    * Constructs a new instance of this library with the
    * PApplet as a reference.
    *
    * @param parent
    *           the parent applet
    */
   public CamZup ( final PApplet parent ) {

      this.parent = parent;

   }
}
