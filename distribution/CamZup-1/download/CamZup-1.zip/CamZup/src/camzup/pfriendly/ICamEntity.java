package camzup.pfriendly;

/**
 * Maintains consistent behavior between camera entities.
 */
public interface ICamEntity {}
