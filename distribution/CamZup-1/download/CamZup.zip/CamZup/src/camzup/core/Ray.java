package camzup.core;

/**
 * An abstract class to serve as a parent for rays.
 */
public class Ray implements IRay {

   /**
    * The default constructor.
    */
   public Ray ( ) {}

}
