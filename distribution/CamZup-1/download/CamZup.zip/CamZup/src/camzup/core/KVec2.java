package camzup.core;

class KVec2 extends Vec2 {

   public KVec2 ( ) { super(); }

   public KVec2 ( final boolean x, final boolean y ) { super(x, y); }

   public KVec2 ( final float x, final float y ) {

      super(x != x ? 0.0f : x, y != y ? 0.0f : y);
   }

   public KVec2 ( final String xstr, final String ystr ) { super(xstr, ystr); }

   public KVec2 ( final Vec2 v ) { super(v); }

   @Override
   public KVec2 clone ( ) { return new KVec2(this.x, this.y); }

   public KVec2 dec ( ) { return new KVec2(this.x - 1.0f, this.y - 1.0f); }

   public void divAssign ( final float f ) {

      if ( f != 0.0f && f == f ) {
         this.x /= f;
         this.y /= f;
      } else {
         this.x = 0.0f;
         this.y = 0.0f;
      }
   }

   public void divAssign ( final KVec2 kv ) {

      if ( kv != null ) {
         this.x = Utils.div(this.x, kv.x);
         this.y = Utils.div(this.y, kv.y);
      }
   }

   public float getX ( ) { return this.x; }

   public float getY ( ) { return this.y; }

   public KVec2 inc ( ) { return new KVec2(this.x + 1.0f, this.y + 1.0f); }

   public void minusAssign ( final KVec2 kv ) {

      if ( kv != null ) {
         this.x -= kv.x;
         this.y -= kv.y;
      }
   }

   public void plusAssign ( final KVec2 kv ) {

      if ( kv != null ) {
         this.x += kv.x;
         this.y += kv.y;
      }
   }

   public void remAssign ( final float f ) {

      if ( f != 0.0f && f == f ) {
         this.x %= f;
         this.y %= f;
      }
   }

   public void remAssign ( final KVec2 kv ) {

      if ( kv != null ) {
         this.x = Utils.fmod(this.x, kv.x);
         this.y = Utils.fmod(this.y, kv.y);
      }
   }

   public void setX ( final float x ) { if ( x == x ) { this.x = x; } }

   public void setY ( final float y ) { if ( y == y ) { this.y = y; } }

   public void timesAssign ( final float f ) {

      if ( f == f ) {
         this.x *= f;
         this.y *= f;
      }
   }

   public void timesAssign ( final KVec2 kv ) {

      if ( kv != null ) {
         this.x *= kv.x;
         this.y *= kv.y;
      }
   }

}
